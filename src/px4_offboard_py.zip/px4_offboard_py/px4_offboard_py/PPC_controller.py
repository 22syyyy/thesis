# ppc_controller.py
import numpy as np
import math


class PPCController:
    def __init__(self):

        #PPC parameters
        self.rho_para = {
             'position':{
                  'px':(5.0, 0.1, 0.5),
                  'py':(5.0, 0.1, 0.5),
                  'pz':(3.0, 0.1, 1.0)
             },
             'velocity':{
                  'vx':(2.0, 0.1, 0.5),
                  'vy':(2.0, 0.1, 0.5),
                  'vz':(2.0, 0.1, 1.0)
            },
             'angular':{
                 'phitheta1': (0.5, 0.05, 0.5),  
                 'phitheta2': (0.5, 0.05, 0.5),  
                 'psi': (0.5, 0.05, 0.5)  
            },
              'omega' :{  
                 'omega_phi': (0.3, 0.1, 0.5),
                 'omega_theta': (0.3, 0.1, 0.5), 
                 'omega_psi': (0.3, 0.1, 0.5)   
            }
         }
        
        #control gain
        self.k = {
            'position': 1.5,    
            'velocity_xy': 1.0, 
            'velocity_z': 1.0,  
            'angular1': 2.0,
            'angular2':2.0,    
            'omega': 10.0 
        }

    
    #PPC CONTROLLER
    #############
    def rho_calculation(self, layer, axis, t): 
        rho0, rho_inf, l = self.rho_para[layer][axis]
        return (rho0 - rho_inf) * math.exp( -l * t) + rho_inf

    def transformation(self, e, rho):
        xi = e / rho
        xi = np.clip(xi, -0.999, 0.999)  # avoiding devide by zero
        return 0.5 * np.log((1 + xi) / (1 - xi))
    #################

    ##################
    def PPC(self, current_pos, target_pos, target_yaw, current_vel, current_euler, current_omega, t):


        self.e_pos = target_pos - current_pos

        self.rho_pos = np.array ([
            self.rho_calculation('position', axis, t) for axis in ['x', 'y', 'z']
             ])
        
        self.xi_pos = self.e_pos / self.rho_pos
        self.epsilon_pos = self.transformation(self, self.e_pos, self.rho_pos)
        self.r_pos = np.diag(1 / (1 -(self.xi_pos)**2))
        self.v_ref = -self.k['position'] * (1 /self.rho_pos) * self.r_pos * self.epsilon_pos

        #velocity layer (# Velocity in NED frame)
        self.e_vel = self.v_ref - current_vel
        self.rho_vel = np.array ([
            self.rho_calculation('velocity', axis, t) for axis in ['vx', 'vy', 'vz']
             ])
        self.xi_vel = self.e_vel / self.rho_vel
        self.epsilon_vel = self.transformation(self, self.e_vel, self.rho_vel)
        self.r_vel = np.diag(1 / (1 -(self.xi_vel)**2))

        self.Fz_ref = -self.k['velocity_z'] * (1 /self.rho_vel[2]) * (1 / (1 - (self.xi_vel[2])**2)) * self.epsilon_pos[2]
        #Fz needs to be published as thrust


        #subscriber from phi, theta, psi
        phi, theta, psi = current_euler
        Cphi, Sphi = np.cos(phi), np.sin(phi) 
        Ctheta, Stheta = np.cos(theta), np.sin(theta)
        Cpsi, Spsi = np.cos(psi), np.sin(psi)
        Ttheta = np.tan(theta)
        

        self.R_psi = np.array([
            [Cpsi, -Spsi],
            [Spsi, Cpsi]
            ])
        
        
        self.rho_vel_xy_inv = np.diag(1 / self.rho_vel[0:2])
        self.r_vel_xy = self.r_vel[0:2]
        self.xi_vel_xy = np.diag(self.xi_vel_xy[0:2])
        self.T_phitheta_r = -self.k['velocity_xy'] * self.R_psi.T @ self.rho_vel_xy_inv @ self.r_vel_xy @ self.xi_vel_xy /self.Fz_ref

        #angular layer 
        self.current_T_phitheta = np.array[(Stheta*Cphi, -Sphi)]
        self.e_T_phitheta = self.current_T_phitheta - self.T_phitheta_r

        
        self.current_yaw = self.vehicle_local_position.heading
        #Euler yaw angle transforming the tangent plane relative to NED earth-fixed frame, -PI..+PI,  (radians)
        self.e_yaw = target_yaw - psi

        self.e_angular = np.vstack((self.e_T_phitheta, self.e_yaw))

        self.rho_phitheta = np.array([
            self.rho_calculation('angular', axis, t) for axis in ['phitheta1', 'phitheta2']
        ])
        self.rho_yaw = self.rho_calculation('angular', 'psi', t)

        self.rho_angular = np.vstack((self.rho_phitheta, self.rho_yaw))
        self.xi_angular = self.e_angular / self.rho_angular

        self.r_angular = np.diag(1 / (1 -(self.xi_angular)**2))

        self.epsilon_phitheta = self.transformation(self, self.e_angular, self.rho_angular)
      
        self.R_phitheta = np.array([[Cpsi/Ctheta, Spsi/Ctheta],
                                   [-Sphi, Cpsi]
                                   ])
        self.J_phitheta = np.array([[-Stheta*Sphi, Ctheta*Cphi],
                                    [-Cphi, 0]
                                    ])

       
        
        A = self.k['angular1'] * np.linalg.inv(self.R_phitheta) @ np.linalg.inv(self.J_phitheta) @ np.linalg.inv(self.rho_angular[0:2]) @ self.r_angular[0:2] @self.epsilon_phitheta[0:2]
        B = self.k['angular2'] * (1 / self.rho_angular[2]) * self.r_angular[2] * self.epsilon_phitheta[2] + current_omega[0] * Cpsi * Ttheta + self.current[1] * Spsi * Ttheta
        self.omega_ref = -np.vstack((A,B))


        #angular velocities
        self.e_omega = current_omega - self.omega_ref
        self.rho_omega = np.array ([
            self.rho_calculation('omega', axis, t) for axis in ['omega_phi', 'omega_theta', 'omega_psi']
             ])
        self.xi_omega = self.e_omega / self.rho_omega
        self.epsilon_omega = self.transformation(self, self.e_omega, self.rho_omega)
        self.rho_omega = np.diag(1 / (1 -(self.xi_omega)**2))

        self.tau = -self.k['omega'] * (1 /self.rho_omega) * (1 / self.rho_omega) * self.epsilon_omega

        return self.tau, self.Fz_ref
    


    #################